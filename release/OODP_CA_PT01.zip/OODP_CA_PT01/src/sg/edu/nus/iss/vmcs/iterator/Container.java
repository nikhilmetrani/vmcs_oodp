package sg.edu.nus.iss.vmcs.iterator;

public interface Container {
	public Iterator getIterator();
}
