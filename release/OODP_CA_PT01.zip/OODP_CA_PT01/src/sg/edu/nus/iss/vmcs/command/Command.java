package sg.edu.nus.iss.vmcs.command;

public interface Command {
	
	void execute(CommandParam object);

}