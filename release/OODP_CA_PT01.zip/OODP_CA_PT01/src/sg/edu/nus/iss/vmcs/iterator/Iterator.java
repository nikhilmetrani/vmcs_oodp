package sg.edu.nus.iss.vmcs.iterator;

public interface Iterator {
	 public boolean hasNext();
	 public Object next();
}
